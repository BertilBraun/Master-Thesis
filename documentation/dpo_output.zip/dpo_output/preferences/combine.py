import json

with open('preferences_generated_by_run_7.json', 'r') as f7, open(
    'preferences_generated_by_run_1.json', 'r'
) as f1, open('preferences_generated_by_run_2.json', 'r') as f2:
    all_preferences = json.load(f7) + json.load(f1) + json.load(f2)

for preference in all_preferences:
    preference['prompt'] = preference['prompt'].removesuffix('Domain: "')
    if not preference['chosen'].startswith('Domain: "'):
        preference['chosen'] = 'Domain: "' + preference['chosen']
    if not preference['rejected'].startswith('Domain: "'):
        preference['rejected'] = 'Domain: "' + preference['rejected']

with open('all_preferences.json', 'w') as f:
    json.dump(all_preferences, f, indent=4, ensure_ascii=False, sort_keys=False)

print(len(all_preferences))
